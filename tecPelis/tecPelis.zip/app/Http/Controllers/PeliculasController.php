<?php namespace App\Http\Controllers;

class PeliculasController extends Controller {

    const MODEL = "App\Peliculas";

    use RESTActions;

}
