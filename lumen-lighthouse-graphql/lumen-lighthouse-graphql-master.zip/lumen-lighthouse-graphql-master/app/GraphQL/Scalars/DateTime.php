<?php

namespace App\GraphQL\Scalars;


use Nuwave\Lighthouse\Schema\Types\Scalars\DateTime as LightDateTime;


class DateTime extends LightDateTime
{

}
